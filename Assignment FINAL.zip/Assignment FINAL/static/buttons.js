
$(document).ready(function () {
    refreshTable()
    PopulateBox();               //this part runs the following functions once the HTML has loaded.
   
});

function refreshTable(){
    $.getJSON('http://127.0.0.1:5000/assignment/lists/users/api', function(data){   //tells the website where to get the JSON from and run a function with the variable data as parameter
        var userListData = '';
        $.each(data, function(key, value){       //runs a function that creates Table Cells for each value passed into the function from the JSON
            var count = 0;
            count.toString;
            userListData += '<tr id="User" class="Row">';     //creates a row with the class "Row"
            userListData += '<td id="user" class ="ID" >' + value.id+'</td>';     //populates the above row with table cells.
            userListData += '<td id="user" class = "First">' + value.first+'</td>';
            userListData += '<td id="3" class="Last">' + value.last+'</td>';
            userListData += '<td id="4" class="Email">' + value.email+'</td';
            userListData += '</tr>'
        });
        $('table').append(userListData); //apends the element with class table
    });
}

function PopulateBox(){
    
   
    $('#tblUsers').on('click','.Row', function() {        //tells the HTML to run a function when the row with Class "Row", in table with ID tblUsers, is clicked to run a function that populates the boxes below
        var currentRow = $(this).closest("tr");
        var MyBox0 = document.getElementById('userID');         //stores the 'input' element with ID 'userID'
        var MyBox1 = document.getElementById('userEmail');          //stores the 'input' element with ID 'userEmail'
        var MyBox2 = document.getElementById('userFirstName');      //stores the 'input' element with ID 'userFirstName'
        var MyBox3 = document.getElementById('userLastName');       //stores the 'input' element with ID 'userLastName'
        var col1 = currentRow.find(".ID").html();      //this line makes a variable  and stores the value of the nearest element with class ID and turns into HTML
        var col2 = currentRow.find(".First").html();    //this line makes a variable and stores the value of the nearest element with class First and turns into HTML
        var col3 = currentRow.find(".Last").html();    //this line makes a variable and stores the value of the nearest element with class Last and turns into HTML
        var col4 = currentRow.find(".Email").html();  //this line makes a variable and stores the value of the nearest element with the class Email and turns into HTML
        var data = col1 + "\n" + col2 + "\n" + col3 + "\n" + col4;   //this stores everything in col variable and was used for debugging
        MyBox0.value = col1;      //makes the content in each input box the value of each col variable 
        MyBox1.value = col2;        
        MyBox2.value = col3;
        MyBox3.value = col4;
});
};
function UpdateUser(){
    var MyBox0 = document.getElementById('userID');      //this defines the input box with class UserID
    var MyBox1 = document.getElementById('userEmail');   //this defines the input box with class userEmail
    var MyBox2 = document.getElementById('userFirstName');  //this defines the input box with class userFirstName
    var MyBox3 = document.getElementById('userLastName');   //this defines the input box with class userLastName
        
    var col1 = MyBox0.value;    //stores the value in each box        
    var col2 = MyBox1.value;
    var col3 = MyBox2.value;
    var col4 = MyBox3.value;
    const requestURL = 'http://127.0.0.1:5000/assignment/lists/users/api/' + col1;   //makes a link for the JSON for a user with the ID stored in col1
    const request = new XMLHttpRequest(); //creates a reqyest with the URL outlined above
    request.open('PUT', requestURL, true);   //makes the JSON request into a 'PUT' request
    request.setRequestHeader('Content-Type', 'application/json');   //tells the browser what type of data it is sending.
    if (request.readyState === 4 && request.status === 200) {
            var json = JSON.parse(request.responseText);
            
        }
        
        data = JSON.stringify({"id": col1, "first": col2, "last": col3, "email" : col4});  //this makes the JSON datatype into a string datatype, so it can be stored in user_list in the Flask back-end
        request.send(data);  //sends the request
    setTimeout(function () {window.location.reload();}, 500); //reloads the web page to show the changes made to the user details
    return false;
    };

function DeleteUser(){
    var MyBox0 = document.getElementById('userID');   //defines the input box with ID userID
    var col1 = MyBox0.value;        //stores the value in MyBox0
    const requestURL = 'http://127.0.0.1:5000/assignment/lists/users/api/' + col1; //makes a link for the JSON for a used with the ID stored in col1
    const request = new XMLHttpRequest();  //makes a request with the link above
    request.open('DELETE', requestURL, true);    //makes the request a 'DELETE' request
    request.setRequestHeader('Content-Type', 'application/json'); //tells the browser what type of data it is sending
    if (request.readyState === 4 && request.status === 200) {
            var json = JSON.parse(request.responseText);
            
        }
        request.send();  //sends the JSON request
    setTimeout(function () {window.location.reload();}, 500);  //reloads the web page to show the deletion of a user
    return false;
    
};
function CreateUser(){
    var MyBox1 = document.getElementById('userEmail');    //defines the input box with ID userEmail
    var MyBox2 = document.getElementById('userFirstName');   //defines the input box with ID userFirstName
    var MyBox3 = document.getElementById('userLastName');        //defines the input box with ID userLastName
    var col2 = MyBox1.value;    //stores the values in the input boxes
    var col3 = MyBox2.value;
    var col4 = MyBox3.value;
    const requestURL = 'http://127.0.0.1:5000/assignment/lists/users/api'; // makes a link for user_list in the Flask back-end
    const request = new XMLHttpRequest();   //makes the JSON request 
    request.open('POST', requestURL, true);    //makes the request a POST request
    request.setRequestHeader('Content-Type', 'application/json');  //tells the browser what type of data it is sending
    if (request.readyState === 4 && request.status === 200) {
            var json = JSON.parse(request.responseText);
            
        }
        
        data = JSON.stringify({"first": col3, "last": col4, "email" : col2});   //merges all the values together and makes them into strings
        request.send(data);  //sends the JSON request
    setTimeout(function () {window.location.reload();}, 500);  //reloads the web page to show the new created user
    return false;
    
};
