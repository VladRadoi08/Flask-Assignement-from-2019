
from flask import Flask, jsonify, abort, make_response, request, render_template

app = Flask(__name__)

user_list = [
    {
        'id': 1,
        'first': 'Lee',
        'last': 'Nevill',
        'email': 'lee.nevill@reqres.com'
    },
    {
        'id': 2,
        'first': 'Lewis',
        'last': 'Hamilton',
        'email': 'lewis.hamilton@reqres.com'                            #this is a list of users stored on the back-end server
    },
    {
        'id': 3,
        'first': 'Rebecca',
        'last': 'Davies',
        'email': 'rebecca.davies@reqres.com'
    },
    {
        'id': 4,
        'first': 'Gernot',
        'last': 'Liebchen',
        'email': 'gernot.liebchen@reqres.com'
    },
    {
        'id': 5,
        'first': 'Jordan',
        'last': 'Le Egg',
        'email': 'jordan.egg@reqres.com'
    }

]


@app.route('/assignment/lists/users/api/<int:user_id>', methods=['GET'])      #this specifies where resources are and what type of request to make.
def get_user(user_id):
    user = [user for user in user_list if user['id'] == user_id]                #this loop iterates through user_list to find a user based on an ID
    if len(user) == 0:                                          #this checks if the ID of the user is more than 1, if it isnt it return a 404 error
        abort(404)
    return jsonify({'users': user_list[0]})         #returns the wanted user's details as JSON, which can be used by the front-end and the browser


@app.route('/assignment/lists/users/api', methods=['GET']) #this specifies where resources are and what type of request to make.
def get_users():
    return jsonify(user_list)    #this function returns the whole of user_list as JSON, which the front-end and brower can use


@app.errorhandler(404)
def not_found(error):
    return make_response(jsonify({'error': 'Not Found'}), 404)    #this line makes a 404 error in JSON, which can be used by the front-end


@app.route('/assignment/lists/users/api', methods=['POST']) #this specifies where resources are and what type of request to make.
def create_user():
    if not request.json or not 'first' in request.json:  #this makes sure that the new user request is in JSON and includes a 1st name
        abort(420)
    user = {
        'id': user_list[-1]['id'] + 1,              #iterate ID's by 1 when making a new request
        'first': request.json['first'],             #the following lines specify wehre to store inputted information
        'last': request.json.get('last', ""),
        'email': request.json.get('email')
    }
    user_list.append(user)   #adds the new user to user_list
    return jsonify({'user': user_list}), 201    #returns the new user's info with a 201 CREATED  status code


@app.route('/assignment/lists/users/api/<int:user_id>', methods=['PUT'])
def update_user(user_id):
    user = [user for user in user_list if user['id'] == user_id]            #this function checks if what's been inputted is not empty and if it's
    if len(user) == 0:                                                      #made out of letter, if not the servers sends a 400 error
        abort(404)                                                          #if the input is correct it updates the desired user
    if not request.json:
        abort(400)
    if 'first' in request.json and type(request.json['first']) != str:
        abort(400)
    if 'last' in request.json and type(request.json['last']) is not str:
        abort(400)
    user[0]['first'] = request.json.get('first', user[0]['first'])
    user[0]['last'] = request.json.get('last', user[0]['last'])
    return jsonify({'user': user[0]})


@app.route('/assignment/lists/users/api/<int:user_id>', methods=['DELETE'])     #this function deletes a user
def delete_user(user_id):
    user = [user for user in user_list if user['id'] == user_id]                #in the function, it checks if the request has an ID
    if len(user) == 0:                                                          #if it doesnt, thne a 404 error is shown
        abort(404)
    user_list.remove(user[0])
    return jsonify({'result': True})


@app.route('/',methods=['GET'])
def template():
    return render_template("users.html")     #this function loads the HTML for the website.


if __name__ == '__main__':
    app.run()
